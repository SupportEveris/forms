<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="Content-Security-Policy" content="script-src 'self' 'nonce-<?php echo $this->scope["nonce"];?>';">
    <meta http-equiv="X-Content-Security-Policy" content="script-src 'self' 'nonce-<?php echo $this->scope["nonce"];?>';">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OSHA</title>
    
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/bootstrap-theme.css" rel="stylesheet" type="text/css">
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/crop_style.css" rel="stylesheet" type="text/css">
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/select2.css" rel="stylesheet" type="text/css">
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/sidebar.css" rel="stylesheet" type="text/css">
    <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/style.css" rel="stylesheet" type="text/css">
    <?php if ((isset($this->scope["printable"]) ? $this->scope["printable"] : null)) {
?>
        <link href="https://healthy-workplaces.eu/partner/forms/mvc/view/css/print.css" rel="stylesheet" type="text/css">
    <?php 
}?>

    <script src="https://healthy-workplaces.eu/partner/forms/mvc/view/js/jquery.min.js"></script>
    <script src="https://healthy-workplaces.eu/partner/forms/mvc/view/js/magnific-popup.js"></script>
    <script src="https://healthy-workplaces.eu/partner/forms/mvc/view/js/script.cropbox.js"></script>
    <script src="https://healthy-workplaces.eu/partner/forms/mvc/view/js/scripts.js"></script>
    <script src="https://healthy-workplaces.eu/partner/forms/mvc/view/js/select2.full.js"></script>


</head>
<body>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>