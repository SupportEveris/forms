<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="control-group <?php echo $this->scope["required"];?>">
    <div>
        <label class="control-label screen-left" for="<?php echo $this->scope["fieldName"];?>"><?php echo $this->scope["fieldLabel"];?></label>
        <?php if (! empty($this->scope["fieldPublicProfile"])) {
?><img src="<?php echo $this->scope["appurl"];?>mvc/view/img/screen.png" title="Fields displayed on campaign site" class="screen-right"/><?php 
}?>

    </div>
    <?php if (! empty($this->scope["fieldHelpText"])) {
?>
    <p class="help-block"><?php echo $this->scope["fieldHelpText"];?></p>
    <?php 
}?>

    <div class="controls">
        <select <?php echo $this->scope["disabled"];?> class="field dropdown-multiple" id="<?php echo $this->scope["fieldName"];?>" name="<?php echo $this->scope["fieldName"];?>[]"
                data-section="<?php echo $this->scope["fieldSection"];?>" multiple="multiple">
            <?php 
$_fh3_data = (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null);
if ($this->isTraversable($_fh3_data) == true)
{
	foreach ($_fh3_data as $this->scope['id']=>$this->scope['value'])
	{
/* -- foreach start output */
?>
            <?php if ((isset($this->scope["value"]["selected"]) ? $this->scope["value"]["selected"]:null)) {
?>
            <option value="<?php echo $this->scope["value"]["id"];?>" selected="selected"><?php echo $this->scope["value"]["name"];?></option>
                <?php 
}
else {
?>
            <option value="<?php echo $this->scope["value"]["id"];?>"><?php echo $this->scope["value"]["name"];?></option>
                <?php 
}?>

            <?php 
/* -- foreach end output */
	}
}?>

        </select>
    </div>
</div>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>