<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="control-group <?php echo $this->scope["required"];?>">
    <div>
        <label class="control-label screen-left" for="<?php echo $this->scope["fieldName"];?>"><?php echo $this->scope["fieldLabel"];?></label>
        <?php if (! empty($this->scope["fieldPublicProfile"])) {
?><img src="<?php echo $this->scope["appurl"];?>mvc/view/img/screen.png" title="Fields displayed on campaign site" class="screen-right"/><?php 
}?>

    </div>
    <?php if (! empty($this->scope["fieldHelpText"])) {
?>
    <p class="help-block"><?php echo $this->scope["fieldHelpText"];?></p>
    <?php 
}?>

    <!-- <div class="controls"> -->
        <label class="radio inline" for="<?php echo $this->scope["fieldName"];?>">
            <input <?php echo $this->scope["disabled"];?> class="field" name="<?php echo $this->scope["fieldName"];?>" id="<?php echo $this->scope["fieldName"];?>-yes" value="Yes" type="radio" <?php if ((isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null) && (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null) != 'No') {
?>checked="true" <?php 
}?> data-section="<?php echo $this->scope["fieldSection"];?>">
            Yes
        </label>
        <label class="radio inline" for="<?php echo $this->scope["fieldName"];?>">
            <input <?php echo $this->scope["disabled"];?> class="field" name="<?php echo $this->scope["fieldName"];?>" id="<?php echo $this->scope["fieldName"];?>-no" value="No" type="radio" <?php if (! (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null) || (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null) == 'No') {
?>checked="true" <?php 
}?> data-section="<?php echo $this->scope["fieldSection"];?>">
            No
        </label>
    <!-- </div> -->
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>