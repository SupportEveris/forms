<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
if ((isset($this->scope["show_print_version"]) ? $this->scope["show_print_version"] : null) || (isset($this->scope["show_pdf_version"]) ? $this->scope["show_pdf_version"] : null)) {
?>
<script nonce="<?php echo $this->scope["nonce"];?>">
    $(document).ready(function() {
        window.open("<?php echo $this->scope["appurl"];?>&action=<?php if ((isset($this->scope["show_print_version"]) ? $this->scope["show_print_version"] : null)) {
?>printable<?php 
}
else {
?>pdf<?php 
}?>", 'popup');
    });
</script>
<?php 
}?>

<?php if (! (isset($this->scope["printable"]) ? $this->scope["printable"] : null)) {
?>
<?php if ((isset($this->scope["progressbar"]) ? $this->scope["progressbar"] : null)) {
?>
    <div id="blankDiv" style="width: 20%; float: left; height: 3vw;"></div>
    <?php echo $this->scope["progressbar"];?>

<?php 
}?>

<?php if ((isset($this->scope["partner_type"]) ? $this->scope["partner_type"] : null) == "current") {
?>
<!--<div class="review-fields">Please make sure that you thoroughly check, whether all your information is still valid and indicate this by checking the button next to each section</div>-->
<?php 
}?>

<div id="content">
    <?php if ((isset($this->scope["sidebar"]) ? $this->scope["sidebar"] : null)) {

echo $this->scope["sidebar"];

}?>

    <?php if (! ((isset($this->scope["fullwidth"]) ? $this->scope["fullwidth"] : null) !== null)) {
?><div id="form" class="main-form sidebar-border"><?php 
}?>

        <?php if (! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
        <form class="form-horizontal <?php if (! empty($this->scope["partner_type"])) {

echo $this->scope["partner_type"];

}?> <?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>mf<?php 
}?>" method="post" autocomplete="off" action="<?php echo $this->scope["appurl"];?>&action=send<?php if ((isset($this->scope["actionType"]) ? $this->scope["actionType"] : null)) {
?>&action_type=<?php echo $this->scope["actionType"];

}?>" onload="checkAllfields()">
        <?php if ((isset($this->scope["HelpMessage"]) ? $this->scope["HelpMessage"] : null) != "print" && ! (isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>
            <div id="container-message" class="container-message">   
                <div id="MESSAGE">
                    <a class="close">[X]</a>
                    <div style="width: 95%;">
                    Please check whether all your information is still valid, make changes when necessary and tick the green buttons next to each section header when you consider that the information in that section is correct <img style="width: 18px;height: 18px;" src="mvc/view/img/validation-NoCheckv2.png"/>
                    <br>If you are not able to complete/review all information in one session, you can press the "Save a Draft" button <img src="mvc/view/img/saveButtonImg.png"/> (on the left of your screen) and you will receive an email with a link to access again the form for completion.
                    In order to finish and submit the final form it is compulsory to complete <b>all</b> the sections and click on <b>all</b> green buttons next to each section header.
                    </div>
                               
                </div>            
            </div>
        <?php 
}
else {
?>
            <!-- <a id="printpage" style="float: right; margin: 1%; ">
                         <img src="mvc/view/img/print.png" title="Print" height="40" width="40">
                </a> -->
        <?php 
}?>

        <div id="dataErrorDialog" class="dialog errorDialog hidden">
        <a class="closeDialog">[X]</a>
        <img src="mvc/view/img/alertIcon.png"/><br>
        <p>Error: Some fields contain errors</p>
    </div>
    <div id="fillRequiredDialog" class="dialog errorDialog hidden">
        <a class="closeDialog">[X]</a>
        <img src="mvc/view/img/alertIcon.png"/><br>
        <p>Please fill in the required fields</p>
    </div>
    <div id="captchaDialog" class="dialog errorDialog hidden">
        <a class="closeDialog">[X]</a>
        <img src="mvc/view/img/alertIcon.png"/><br>
        <p>The data introduced is not correct. Please try again</p>
    </div>
    <div id="captchaAndFieldDialog" class="dialog errorDialog hidden">
        <a class="closeDialog">[X]</a>
        <img src="mvc/view/img/alertIcon.png"/><br>
        <p>CAPTCHA is incorrect. Try again and mandatory above fields are incompleted. Please check again.</p>
    </div>
    <div id="checkFieldsDialog" class="dialog errorDialog hidden">
        <a class="closeDialog">[X]</a>
        <img src="mvc/view/img/alertIcon.png"/><br>
        <p>Section check cannot be ticked until the mandatory fields are filled</p>
    </div>
    <div id="nameandemailrequiredDialog" class="dialog errorDialog hidden">
        <a class="closeDialog">[X]</a>
        <img src="mvc/view/img/alertIcon.png"/><br>
        <p>The fields Company/Organisation name and E-mail, name and surname of the Primary Contact are required for save the information</p>
        <p class="saveExplanation">When saving as a draft, you will receive an automatic email with a link from which you will be able to come back to continue your application. In order to do so, the completion of the organisation's name and your primary contact's email, name and surname is mandatory</p>
    </div>
    <div id="maxSocialNetDialog" class="dialog errorDialog hidden">
        <a class="closeDialog">[X]</a>
        <img src="mvc/view/img/alertIcon.png"/><br>
        <p>You cannot add more than one profile per social network</p>
    </div>
    <div id="sectionRequiredDialog" class="dialog errorDialog hidden">
        <a class="closeDialog">[X]</a>
        <img src="mvc/view/img/alertIcon.png"/><br>
        <p>There are sections unconfirmed or there are mandatory fields not filled</p>
    </div>
        <?php 
}?>

        <?php if ((isset($this->scope["fieldsValidatingDialog"]) ? $this->scope["fieldsValidatingDialog"] : null)) {
?>
            <div id="fieldsValidatingDialog" class="dialog errorDialog">
                <a class="closeDialog" style="color: black; font-size: inherit;">[X]</a>
                <p style="color: black; font-weight: inherit;">Your changes are being reviewed by the campaign team. <br> You will receive feedback shortly. Thanks for participating in the Healthy Workplaces Campaign.</p>
            </div>
        <?php 
}?>

<?php 
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>