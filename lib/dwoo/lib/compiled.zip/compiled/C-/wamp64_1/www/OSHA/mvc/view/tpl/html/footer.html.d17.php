<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
if (! (isset($this->scope["printable"]) ? $this->scope["printable"] : null)) {
?>
            <?php if (empty($this->scope["hideButtons"]) && ! ( (isset($this->scope["locked"]) ? $this->scope["locked"] : null) && (isset($this->scope["actionType"]) ? $this->scope["actionType"] : null) === "submit" )) {
?>
            <div class="control-group">
                <label class="control-label" for="next"></label>
                <div class="controls">
                    <?php if (! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
                    <input id="next" name="next" value="<?php echo $this->scope["submit_text"];?>" <?php if ((isset($this->scope["actionType"]) ? $this->scope["actionType"] : null) === "submit") {
?>type="submit"<?php 
}
else {
?>type="next"<?php 
}?> />
                    <?php 
}
else {
?>
                    <input id="nextInLocked" class="nextInLocked" name="next" value="<?php echo $this->scope["submit_text"];?>" type="submit" />
                    <?php 
}?>

                </div>
            </div>
            <?php 
}?>

        <?php if (! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
        </form>
        <?php 
}?>

    <?php if (! ((isset($this->scope["fullwidth"]) ? $this->scope["fullwidth"] : null) !== null)) {
?>
    </div>
    <?php 
}?>

</div>
<div class="clear"></div>
<?php 
}
 /* end template body */
return $this->buffer . ob_get_clean();
?>