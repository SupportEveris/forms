<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div id="progressbar" class="center">
    <div class="row">
        <?php 
$_fh2_data = (isset($this->scope["steps"]) ? $this->scope["steps"] : null);
if ($this->isTraversable($_fh2_data) == true)
{
	foreach ($_fh2_data as $this->scope['id']=>$this->scope['step'])
	{
/* -- foreach start output */
?>
        
        <div id="progressbar-<?php echo $this->scope["step"]["index"];?>" class="col-md-4 progressbar-text <?php if ((isset($this->scope["step"]["index"]) ? $this->scope["step"]["index"]:null) == 1) {
?>progressbar-first<?php if ((isset($this->scope["currentStep"]) ? $this->scope["currentStep"] : null) >= (isset($this->scope["step"]["index"]) ? $this->scope["step"]["index"]:null)) {
?>-active<?php 
}

}?> <?php if ((isset($this->scope["step"]["index"]) ? $this->scope["step"]["index"]:null) > 1 && (isset($this->scope["currentStep"]) ? $this->scope["currentStep"] : null) >= (isset($this->scope["step"]["index"]) ? $this->scope["step"]["index"]:null)) {
?>progressbar-active<?php 
}?> <?php if ((isset($this->scope["step"]["index"]) ? $this->scope["step"]["index"]:null) >= (isset($this->scope["totalSteps"]) ? $this->scope["totalSteps"] : null)) {
?>progressbar-last<?php if ((isset($this->scope["currentStep"]) ? $this->scope["currentStep"] : null) >= (isset($this->scope["step"]["index"]) ? $this->scope["step"]["index"]:null)) {
?>-active<?php 
}

}?>">
        <a data-ajax="?route=<?php echo $this->scope["current_Route"];?>&amp;action=savesessionajax" href="<?php echo $this->scope["appurl"];?>?<?php echo $this->scope["step"]["route"];?>" class="progressbar-text-a"><?php echo $this->scope["step"]["index"];?>. <?php echo $this->scope["step"]["label"];?></a>
        </div>
        <?php 
/* -- foreach end output */
	}
}?>

    </div>
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>