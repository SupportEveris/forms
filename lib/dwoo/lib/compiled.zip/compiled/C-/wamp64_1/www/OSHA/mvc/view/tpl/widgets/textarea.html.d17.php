<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="control-group <?php echo $this->scope["required"];?>">
    <div>
        <label class="control-label screen-left" style="max-width: 90%;" for="<?php echo $this->scope["fieldName"];?>"><?php echo $this->scope["fieldLabel"];?></label>
        <?php if (! empty($this->scope["fieldPublicProfile"])) {
?><img src="<?php echo $this->scope["appurl"];?>mvc/view/img/screen.png" title="Fields displayed on campaign site" class="screen-right"/><?php 
}?>

    </div>
    <?php if (! empty($this->scope["fieldHelpText"])) {
?>
    <p class="help-block"><?php echo $this->scope["fieldHelpText"];?></p>
    <?php 
}?>

    <div class="controls">
        <textarea <?php echo $this->scope["disabled"];?> class="field" id="<?php echo $this->scope["fieldName"];?>" name="<?php echo $this->scope["fieldName"];?>" placeholder="<?php echo $this->scope["fieldPlaceholder"];?>" data-section="<?php echo $this->scope["fieldSection"];?>"><?php if (! empty($this->scope["fieldValue"])) {

echo $this->scope["fieldValue"];

}?></textarea>
    </div>
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>