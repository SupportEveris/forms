<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="control-group <?php echo $this->scope["required"];?>">
    <div>
        <label class="control-label screen-left" for="<?php echo $this->scope["fieldName"];?>"><?php echo $this->scope["fieldLabel"];?></label>
        <?php if (! empty($this->scope["fieldPublicProfile"])) {
?><img src="<?php echo $this->scope["appurl"];?>mvc/view/img/screen.png" title="Fields displayed on campaign site" class="screen-right"/><?php 
}?>

    </div>
    <?php if (! empty($this->scope["fieldHelpText"])) {
?>
    <p class="help-block"><?php echo $this->scope["fieldHelpText"];?></p>
    <?php 
}?>

    <div class="controls">
        <select <?php echo $this->scope["disabled"];?> class="field" id="<?php echo $this->scope["fieldName"];?>" name="<?php echo $this->scope["fieldName"];?>" data-section="<?php echo $this->scope["fieldSection"];?>">
             <option value="">Select an option</option>
            <?php 
$_fh4_data = (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null);
if ($this->isTraversable($_fh4_data) == true)
{
	foreach ($_fh4_data as $this->scope['id']=>$this->scope['value'])
	{
/* -- foreach start output */
?>
            <?php if (( (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) === (isset($this->scope["value"]) ? $this->scope["value"] : null) )) {
?>
                <?php if (( ( (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) != null || (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) === 0 ) && ( (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) == (isset($this->scope["id"]) ? $this->scope["id"] : null) || (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) == (isset($this->scope["value"]) ? $this->scope["value"] : null) ) )) {
?>
                <option value="<?php echo $this->scope["id"];?>" selected="selected"><?php echo $this->scope["value"];?></option>
                <?php 
}
else {
?>
                <option value="<?php echo $this->scope["id"];?>"><?php echo $this->scope["value"];?></option>
                <?php 
}?>

            <?php 
}
else {
?>
                <?php if (( ( (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) != null || (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) === 0 ) && ( (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) == (isset($this->scope["id"]) ? $this->scope["id"] : null) ) )) {
?>
                <option value="<?php echo $this->scope["id"];?>" selected="selected"><?php echo $this->scope["value"];?></option>
                <?php 
}
else {
?>
                <option value="<?php echo $this->scope["id"];?>"><?php echo $this->scope["value"];?></option>
                <?php 
}?>

            <?php 
}?>

            <?php 
/* -- foreach end output */
	}
}?>

        </select>
    </div>
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>