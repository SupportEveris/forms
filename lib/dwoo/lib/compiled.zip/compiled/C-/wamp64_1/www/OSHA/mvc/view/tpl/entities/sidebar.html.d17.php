<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="nav-side-menu">
    <div id="sidebar-top" class="menu-list">
        <ul id="menu-content" class="menu-content collapse out">
            
            <li class="tituloSidebar">Navigation Panel and Status</li>
            
            <?php 
$_fh1_data = (isset($this->scope["sections"]) ? $this->scope["sections"] : null);
if ($this->isTraversable($_fh1_data) == true)
{
	foreach ($_fh1_data as $this->scope['sectionKey']=>$this->scope['section'])
	{
/* -- foreach start output */
?>
                <li class="section-title"><a data-ajax="?route=<?php echo $this->scope["currentRoute"];?>&amp;action=savesessionajax" href="<?php echo $this->scope["appurlsidebar"];?>?route=<?php echo $this->scope["section"]["route"];?>"><?php echo $this->scope["section"]["title"];?></a></li>
                <?php 
$_fh0_data = (isset($this->scope["section"]["sections"]) ? $this->scope["section"]["sections"]:null);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['subsectionKey']=>$this->scope['subsection'])
	{
/* -- foreach start output */
?>
            <?php if ((isset($this->scope["subsectionKey"]) ? $this->scope["subsectionKey"] : null) != "OTHER_USERS") {
?>
            <li class="section <?php echo $this->scope["subsectionKey"];?> <?php if ($this->readVar("sections_validated.".(isset($this->scope["subsectionKey"]) ? $this->scope["subsectionKey"] : null)) == "0") {
?>sidebar-error<?php 
}?>" data-section="<?php echo $this->scope["subsectionKey"];?>">
                <a data-ajax="?route=<?php echo $this->scope["currentRoute"];?>&amp;action=savesessionajax" href="<?php echo $this->scope["appurlsidebar"];?>?route=<?php echo $this->scope["section"]["route"];?>#<?php echo $this->scope["subsectionKey"];?>"><?php echo $this->scope["subsection"];?></a>
            </li>
            <?php 
}
elseif ((isset($this->scope["subsectionKey"]) ? $this->scope["subsectionKey"] : null) == "OTHER_USERS" && (isset($this->scope["mf"]) ? $this->scope["mf"] : null) == "mf") {
?>
            <li class="section OTHER_USERS" data-section="OTHER_USERS">
                <a href="<?php echo $this->scope["appurlsidebar"];?>?route=contact#OTHER_USERS">Other users</a>
            </li>
            <?php 
}?>

                <?php 
/* -- foreach end output */
	}
}?>

            <?php 
/* -- foreach end output */
	}
}?>

            
            
            <?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null) != "mf") {
?>
            <li id="sidebar-bottom" class="menu-list saveAndPrintButtons">
                <?php if (! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
                <button id="save" name="save" <?php if ((isset($this->scope["graceperiod"]) ? $this->scope["graceperiod"] : null)) {
?>class="hidden"<?php 
}?>>Save a draft</button>
                <?php 
}?>

                <a class="print action-print" data-ajax="?route=<?php echo $this->scope["currentRoute"];?>&amp;action=savesessionajax" data-href="<?php echo $this->scope["appurl"];?>&action=printable"> </a>
            </li>
            <?php 
}?>

            <!-- <li class="fields-campaign" <?php if ((isset($this->scope["graceperiod"]) ? $this->scope["graceperiod"] : null)) {
?>class="hidden"<?php 
}?>>When saving as a draft, you will receive an automatic email with a link from which you will be able to come back to continue your application. In order to do so, the completion the organisation's name and your primary contact's email is mandatory</li> -->
            
            <?php if ((isset($this->scope["returnCode"]) ? $this->scope["returnCode"] : null) === "error") {
?>
                <div class = "saveDialog">
                    <a class="closeDialog">[X]</a>
                    <img src="mvc/view/img/alertIcon.png"/><br>
                    <p>An error has occurred saving the data</p>
                </div>
            <?php 
}?>

            <?php if ((isset($this->scope["returnCode"]) ? $this->scope["returnCode"] : null) === "ok") {
?>
                <div class = "saveDialog">
                    <a class="closeDialog">[X]</a>
                    <img src="mvc/view/img/green-tick.png"/><br>
                    <p>The information has been saved correctly</p>
                    <p class="saveExplanationSave">When saving as a draft, you will receive an automatic email with a link from which you will be able to come back to continue your application. In order to do so, the completion of the organisation's name and your primary contact's email is mandatory</p>
                </div>
            <?php 
}?>

            
            
            <li class="separator">&nbsp;</li>
            
            <li class="tituloSidebar">Relevant for you</li>
            
            <?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null) != "mf") {
?>
                <?php if ((isset($this->scope["category"]) ? $this->scope["category"] : null) == 'ocp') {
?>
                    <li class="export-pdf"><a href="mvc/view/pdf/HWC 2016-17_Official Campaign_Partner_Offer.pdf" target="_blank">> See Campaign partnership offer</a></li>
                <?php 
}
elseif ((isset($this->scope["category"]) ? $this->scope["category"] : null) == 'mp') {
?>
                    <li class="export-pdf"><a href="mvc/view/pdf/HWC 2016-17_Media_Partner_Offer.pdf" target="_blank">> See Campaign partnership offer</a></li>
                <?php 
}
elseif ((isset($this->scope["category"]) ? $this->scope["category"] : null) == 'fop') {
?>
                    <li class="export-pdf"><a href="mvc/view/pdf/HWC 2016-17_Official Campaign_Partner_Offer.pdf" target="_blank">> See Campaign partnership offer</a></li>
                <?php 
}?>

            <?php 
}?>

            <?php if ((isset($this->scope["category"]) ? $this->scope["category"] : null) == 'ocp') {
?>
                <li class="export-pdf"><a href="mvc/view/pdf/EU-OSHA_HWC_FIN_OCP_20160126_01.png" target="_blank">> See how your data will appear on the Campaign website</a></li>
            <?php 
}
elseif ((isset($this->scope["category"]) ? $this->scope["category"] : null) == 'mp') {
?>
                <li class="export-pdf"><a href="mvc/view/pdf/EU-OSHA_HWC_FIN_MP_20160119_02.png" target="_blank">> See how your data will appear on the Campaign website</a></li>
            <?php 
}
elseif ((isset($this->scope["category"]) ? $this->scope["category"] : null) == 'fop') {
?>
                <li class="export-pdf"><a href="mvc/view/pdf/EU-OSHA_HWC_FIN_FP_20160119_02.png" target="_blank">> See how your data will appear on the Campaign website</a></li>
            <?php 
}?>

            
            
            <li class="separator">&nbsp;</li>
            
            <li class="tituloSidebar">Legend</li>
            <li class="fields-campaign">Required Fields<div class="requiredAsterisk"> *</div></li>
            <li class="fields-campaign">Fields displayed on campaign site<div title="Fields displayed on campaign site" class="screen"></div></li>

        </ul>
    </div>
   <!-- <div class="upArrow">
        <a href="#top">
             <img src="mvc/view/img/upArrow.png" title="Go to top" height="30" width="31">
        </a>
    </div> -->
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>