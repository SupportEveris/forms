<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
if ((isset($this->scope["show_print_version"]) ? $this->scope["show_print_version"] : null) || (isset($this->scope["show_pdf_version"]) ? $this->scope["show_pdf_version"] : null)) {
?>
<script nonce="<?php echo $this->scope["nonce"];?>">
    $(document).ready(function() {
        window.open("<?php echo $this->scope["appurl"];?>&action=<?php if ((isset($this->scope["show_print_version"]) ? $this->scope["show_print_version"] : null)) {
?>printable<?php 
}
else {
?>pdf<?php 
}?>", 'popup');
    });
</script>
<?php 
}?>

<?php if (! (isset($this->scope["printable"]) ? $this->scope["printable"] : null)) {
?>
<?php if ((isset($this->scope["progressbar"]) ? $this->scope["progressbar"] : null)) {

echo $this->scope["progressbar"];

}?>

<?php if ((isset($this->scope["partner_type"]) ? $this->scope["partner_type"] : null) == "current") {
?>
<!--<div class="review-fields">Please make sure that you thoroughly check, whether all your information is still valid and indicate this by checking the button next to each section</div>-->
<?php 
}?>

<div id="content">
    <?php if ((isset($this->scope["sidebar"]) ? $this->scope["sidebar"] : null)) {

echo $this->scope["sidebar"];

}?>

    <?php if (! ((isset($this->scope["fullwidth"]) ? $this->scope["fullwidth"] : null) !== null)) {
?><div id="form" class="main-form sidebar-border"><?php 
}?>

        <?php if (! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
    <form class="form-horizontal <?php if (! empty($this->scope["partner_type"])) {

echo $this->scope["partner_type"];

}?> <?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>mf<?php 
}?>" method="post" action="<?php echo $this->scope["appurl"];?>&action=send<?php if ((isset($this->scope["actionType"]) ? $this->scope["actionType"] : null)) {
?>&action_type=<?php echo $this->scope["actionType"];

}?>" onload="checkAllfields()">
        <?php 
}?>

<?php 
}
 /* end template body */
return $this->buffer . ob_get_clean();
?>