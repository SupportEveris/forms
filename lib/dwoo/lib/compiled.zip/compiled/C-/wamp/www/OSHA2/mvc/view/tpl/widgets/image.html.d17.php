<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="control-group <?php echo $this->scope["required"];?>">
    <label class="control-label" for="<?php echo $this->scope["fieldName"];?>"><?php echo $this->scope["fieldLabel"];?></label>
    <?php if (! empty($this->scope["fieldValue"]["content"])) {
?>
    <div class="<?php echo $this->scope["fieldName"];?>_image_container"><img src="data:image/png;base64,<?php echo $this->scope["fieldValue"]["content"];?>"></div>
    <?php 
}
else {
?>
    <div class="<?php echo $this->scope["fieldName"];?>_image_container" id="<?php echo $this->scope["fieldName"];?>_image_container"></div>
    <?php 
}?>

    <?php if (! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
    <button class="<?php echo $this->scope["fieldName"];?>_popup-modal" href="#<?php echo $this->scope["fieldName"];?>_test-modal">Upload your image</button>
    <?php 
}?>

    <div id="<?php echo $this->scope["fieldName"];?>_test-modal" class="white-popup-block mfp-hide">
        <div class="imageBox" id="<?php echo $this->scope["fieldName"];?>_imageBox">
            <div class="thumbBox" id="<?php echo $this->scope["fieldName"];?>_thumbBox"></div>
            <div class="spinner" id="<?php echo $this->scope["fieldName"];?>_spinner" style="display: none">Loading...</div>
        </div>
        <div class="action">
            <input <?php echo $this->scope["disabled"];?> id="<?php echo $this->scope["fieldName"];?>" name="<?php echo $this->scope["fieldName"];?>" type="hidden">
            <input <?php echo $this->scope["disabled"];?> type="button" id="<?php echo $this->scope["fieldName"];?>_btnCrop" value="Save Image" style="float: right; background: #003399; color: white;" data-section="<?php echo $this->scope["fieldSection"];?>">
            <input <?php echo $this->scope["disabled"];?> type="button" id="<?php echo $this->scope["fieldName"];?>_btnZoomIn" value="+" style="float: right" data-section="<?php echo $this->scope["fieldSection"];?>">
            <input <?php echo $this->scope["disabled"];?> type="button" id="<?php echo $this->scope["fieldName"];?>_btnZoomOut" value="-" style="float: right" data-section="<?php echo $this->scope["fieldSection"];?>">
            <input <?php echo $this->scope["disabled"];?> id="<?php echo $this->scope["fieldName"];?>_file" name="<?php echo $this->scope["fieldName"];?>_file" type="file" data-section="<?php echo $this->scope["fieldSection"];?>"><br/>
        </div>
        <button id="guardarImg" class="guardarImg hidden" name="save_image" data-target="<?php echo $this->scope["fieldName"];?>_image_container" data-cropperkey="<?php echo $this->scope["fieldName"];?>_cropper">Save Image</button>
        <p><a class="<?php echo $this->scope["fieldName"];?>_popup-modal-dismiss" href="#">Close</a></p>

    </div>
</div>

<script type="text/javascript" nonce="<?php echo $this->scope["nonce"];?>">
    $(window).load(function () {
        var options =
        {
            thumbBox: '#<?php echo $this->scope["fieldName"];?>_thumbBox',
            spinner: '#<?php echo $this->scope["fieldName"];?>_spinner',
            imgSrc: ''
        };
        var cropper = $('#<?php echo $this->scope["fieldName"];?>_imageBox').cropbox(options);
        $('#<?php echo $this->scope["fieldName"];?>_file').on('change', function () {
            var reader = new FileReader();
            reader.onload = function (e) {
                options.imgSrc = e.target.result;
                cropper = $('#<?php echo $this->scope["fieldName"];?>_imageBox').cropbox(options);
            };
            if ($('#<?php echo $this->scope["fieldName"];?>_thumbBox').find('img')) {
                $('#<?php echo $this->scope["fieldName"];?>_thumbBox > img').remove();
            }
            reader.readAsDataURL(this.files[0]);
            this.files = [];
        });
        $('#<?php echo $this->scope["fieldName"];?>_btnCrop').on('click', function () {
            var img = cropper.getDataURL();
            if ($('#<?php echo $this->scope["fieldName"];?>_thumbBox').find('img')) {
                $('#<?php echo $this->scope["fieldName"];?>_thumbBox > img').remove();
                $('#<?php echo $this->scope["fieldName"];?>_imageBox').css("background-image", "");
            }
            $('#<?php echo $this->scope["fieldName"];?>_thumbBox').append('<img src="' + img + '">');
            $('#<?php echo $this->scope["fieldName"];?>').attr('value', img);
            $('#guardarImg').click();
        });
        $('#<?php echo $this->scope["fieldName"];?>_btnZoomIn').on('click', function () {
            cropper.zoomIn();
        });
        $('#<?php echo $this->scope["fieldName"];?>_btnZoomOut').on('click', function () {
            cropper.zoomOut();
        })
    });

    $(function () {
        $('.<?php echo $this->scope["fieldName"];?>_popup-modal').magnificPopup({
            key: "<?php echo $this->scope["fieldName"];?>_cropper",
            type: 'inline',
            preloader: true,
            modal: true
        });
        $(document).on('click', '.<?php echo $this->scope["fieldName"];?>_popup-modal-dismiss', function (e) {
            e.preventDefault();
            $.magnificPopup.close();
        });
    });
</script><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>