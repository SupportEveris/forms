<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div style="margin-bottom: 0;" class="control-group <?php echo $this->scope["required"];?>">
    <label class="control-label screen-left" style="margin-bottom: -1.8%; margin-left: 3%; font-weight: normal;" for="<?php echo $this->scope["fieldName"];?>"><?php echo $this->scope["fieldLabel"];?></label>
    <?php if (! empty($this->scope["fieldPublicProfile"])) {
?><img src="<?php echo $this->scope["appurl"];?>mvc/view/img/screen.png" title="Fields displayed on campaign site" class="screen-right"/><?php 
}?>

    <?php if (! empty($this->scope["fieldHelpText"])) {
?>
    <p class="help-block"><?php echo $this->scope["fieldHelpText"];?></p>
    <?php 
}?>

    <div class="controls">
        <input <?php echo $this->scope["disabled"];?> type="checkbox" style="display: block;" class="combined-checkbox" data-target="<?php echo $this->scope["fieldName"];?>" data-section="<?php echo $this->scope["fieldSection"];?>" <?php if ((isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null)) {
?> checked="true" <?php 
}?>/>
        <textarea <?php echo $this->scope["disabled"];?> class="field combined-textbox" <?php if (empty($this->scope["fieldValue"])) {
?>style="display:none;"<?php 
}?> id="<?php echo $this->scope["fieldName"];?>" name="<?php echo $this->scope["fieldName"];?>" placeholder="<?php echo $this->scope["fieldPlaceholder"];?>" type="text" data-section="<?php echo $this->scope["fieldSection"];?>"><?php if (! empty($this->scope["fieldValue"])) {

echo $this->scope["fieldValue"];

}?></textarea>
    </div>
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>