<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="checkbox <?php echo $this->scope["required"];?>">
    <label>
        <input <?php echo $this->scope["disabled"];?> type="checkbox" name="<?php echo $this->scope["fieldName"];?>" id="<?php echo $this->scope["fieldName"];?>" data-section="<?php echo $this->scope["fieldSection"];?>" <?php if ((isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null) == true || (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null) == 'true' || (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null) == 1 || (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null) == 'on') {
?> checked="true" <?php 
}?>/> <?php echo $this->scope["fieldLabel"];?>

    </label>
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>