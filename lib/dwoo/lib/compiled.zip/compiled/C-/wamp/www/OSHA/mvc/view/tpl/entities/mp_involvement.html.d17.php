<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!--<?php if ((isset($this->scope["HelpMessage"]) ? $this->scope["HelpMessage"] : null) != "print") {
?>
<div id="container-message" class="container-message">   

        <div id="MESSAGE">
            Please make sure you thoroughly check, whether all your information is still valid
                       and indicate <br>     this by checking the button next to the appropiate fields
                       <a class="close">[X]</a>
        </div>            
    </div>
<?php 
}
else {
?>
<?php 
}?>-->

<fieldset>
    <legend id="PLEDGE">
        Your Campaign Pledge
        <div data-section="PLEDGE" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    
    <div class="marginRightForm">
        <?php echo $this->scope["attributes"]["involvement_osh_campaignpledge"];?>

    </div>
        <div class="hidden">
            <?php echo $this->scope["attributes"]["helpMessage"];?>

            <?php echo $this->scope["attributes"]["contact_osh_mainemailAux"];?>

            <?php echo $this->scope["attributes"]["company_osh_orgnameAux"];?>

            <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonfirstnameAux"];?>

            <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonlastnameAux"];?>

            <?php echo $this->scope["attributes"]["osh_yourcampaignpledgesection"];?>

        </div>
</fieldset><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>