<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
if ((isset($this->scope["HelpMessage"]) ? $this->scope["HelpMessage"] : null) == "print") {
?>
<div id="headerPrintFriendly">
    <table style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0">
          <tbody><tr>
             <td width="100%"><img class="img_scale" src="http://hwc-crm.osha.europa.eu/healthy-workplaces.jpg" alt="Healthy Workplaces for All Ages" title="Healthy Workplaces for All Ages" style="display: inline-block;" height="112" border="0" width="700"></td>
          </tr>
         </tbody></table>
</div>
<?php 
}?>


<fieldset>
    <legend id="ORGANISATION">
        About your organisation
        <div data-section="ORGANISATION" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="lessSeparator separatorFieldSet"> </div>
    
    <div class="float-left">
        <?php echo $this->scope["attributes"]["company_osh_orgname"];?>

        <?php echo $this->scope["attributes"]["company_osh_logoimage"];?>

        <?php echo $this->scope["attributes"]["company_osh_osh_appform_osh_country"];?>

        <?php echo $this->scope["attributes"]["company_osh_othercountries"];?>

    </div>
    <div class="float-right">
        <?php echo $this->scope["attributes"]["company_osh_orgtype"];?>

        <?php echo $this->scope["attributes"]["company_osh_bussinessector"];?>

        <?php echo $this->scope["attributes"]["company_osh_socialdialoguepartner"];?>

        <?php echo $this->scope["attributes"]["company_osh_yourmissionstatement"];?>

    </div>
    <div class="hidden">
            <?php echo $this->scope["attributes"]["helpMessage"];?>

            <?php echo $this->scope["attributes"]["contact_osh_mainemailAux"];?>

            <?php echo $this->scope["attributes"]["company_osh_orgnameAux"];?>

            <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonfirstnameAux"];?>

            <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonlastnameAux"];?>

            <?php echo $this->scope["attributes"]["osh_aboutyourorgsection"];?>

            <?php echo $this->scope["attributes"]["osh_gencontactinfsection"];?>

            <?php echo $this->scope["attributes"]["osh_aboutyourceosection"];?>

            <?php echo $this->scope["attributes"]["osh_aboutyourrepsection"];?>

        </div>
</fieldset>
<fieldset>
    <legend id="GENERAL_INFORMATION">
        General Contact Information
        <div data-section="GENERAL_INFORMATION" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    
    <div class="float-left">
        <?php echo $this->scope["attributes"]["company_osh_address"];?>

        <?php echo $this->scope["attributes"]["company_osh_zipcode"];?>

        <?php echo $this->scope["attributes"]["company_osh_generalemail"];?>

        <?php echo $this->scope["attributes"]["company_osh_homepage"];?>

        <!-- (CRG - #48 - 13.10.2015) -->
        <div class="socialNetworks">
            <div>
                <label for="company_osh_selectsocialnetworks" style="padding-top: 1vw; display: inline-block;">
                        Social media profiles (Name + Profile ID)
                </label>
                <img src="<?php echo $this->scope["urlBase"];?>mvc/view/img/screen.png" style="margin-bottom: 4%;" title="Fields displayed on campaign site" class="screen-right"/>
            </div>
        <div>
            <select data-tb="socialNetworkTextBox" class="company_osh_selectsocialnetworks" id="company_osh_selectsocialnetworks" name="company_osh_selectsocialnetworks" data-section="GENERAL_INFORMATION"  aria-hidden="true">
                <option data-target="containerSocialNetworks" data-sn="Facebook" data-url="https://www.facebook.com/" id="option_company_osh_facebookprofile" value="company_osh_facebookprofile">Facebook</option>
                <option data-target="containerSocialNetworks" data-sn="Twitter" data-url="https://twitter.com/" id="option_company_osh_twitterprofile" value="company_osh_twitterprofile">Twitter</option>
                <option data-target="containerSocialNetworks" data-sn="Youtube" data-url="https://www.youtube.com/channel/" id="option_company_osh_youtubeprofile" value="company_osh_youtubeprofile">YouTube</option>
                <option data-target="containerSocialNetworks" data-sn="Linkedin" data-url="https://www.linkedin.com/in/" id="option_company_osh_linkedinprofile" value="company_osh_linkedinprofile">LinkedIn</option>
                <option data-target="containerSocialNetworks" data-sn="SlideShare"  data-url="http://www.slideshare.net/" id="option_company_osh_slideprofile" value="company_osh_slideshareprofile">SlideShare</option>
                <option data-target="containerSocialNetworks" data-sn="Pinterest"  data-url="https://www.pinterest.com/" id="option_company_osh_pinterestprofile" value="company_osh_pinterestprofile">Pinterest</option>
                <option data-target="containerSocialNetworks" data-sn="Google+"  data-url="https://plus.google.com/" id="option_company_osh_googleplusprofile" value="company_osh_googleplusprofile">Google+</option>
            </select>
        </div>
        <div style="display: inline-block; margin-left: 1vw;">
            <input  id="socialNetworkTextBox" type="text" placeholder="ID" />
        </div>
		<button type="button" data-selector="company_osh_selectsocialnetworks" data-target="containerSocialNetworks" id="plusSN" data-target="showSN"><img src="<?php echo $this->scope["urlBase"];?>mvc/view/img/add_blue.png" /><span>Add</span></button>
		<div id="listContentSocialNetworks">
			<div id="containerSocialNetworks"></div>
		</div>
                <div id="SocialNetHidden">
                    
                    <?php echo $this->scope["attributes"]["company_osh_facebookprofile"];?>

                    <?php echo $this->scope["attributes"]["company_osh_twitterprofile"];?>

                    <?php echo $this->scope["attributes"]["company_osh_youtubeprofile"];?>

                    <?php echo $this->scope["attributes"]["company_osh_linkedinprofile"];?>

                    <?php echo $this->scope["attributes"]["company_osh_slideshareprofile"];?>

                    <?php echo $this->scope["attributes"]["company_osh_pinterestprofile"];?>

                    <?php echo $this->scope["attributes"]["company_osh_googleplusprofile"];?>

                </div>
          </div>
        <!-- (CRG - #48 - 13.10.2015) -->
    </div>
    <div class="float-right">
        <?php echo $this->scope["attributes"]["company_osh_city"];?>

        <?php echo $this->scope["attributes"]["company_osh_country"];?>

        <?php echo $this->scope["attributes"]["company_osh_generalphone"];?>

        <?php echo $this->scope["attributes"]["company_osh_dedicatedsite"];?>


    </div>
    <!-- <p id="general-text">Please note that all communications related to this application will be addressed to the
        main contact person as indicated below.</p> -->
</fieldset>

<fieldset>
    <legend id="CEO">
        Information about your CEO
        <div data-section="CEO" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    
    <div class="float-left">
        <?php echo $this->scope["attributes"]["company_osh_ceo_firstname"];?>

        <?php echo $this->scope["attributes"]["company_osh_ceo_lastname"];?>

        <?php echo $this->scope["attributes"]["company_osh_ceoimage"];?>

        <?php echo $this->scope["attributes"]["company_osh_positionid"];?>

    </div>
    <div class="float-right">
        <?php echo $this->scope["attributes"]["company_osh_quoteonhwc"];?>

    </div>
</fieldset>
<fieldset>
    <legend id="OSH">
        Your organisation’s health and safety representative
        <div data-section="OSH" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    
    <div id="general-text">Please provide information about the person who represents health and safety interests of
        workers in your organisation.
    </div>
    <div class="float-left">
        <?php echo $this->scope["attributes"]["company_osh_representativeoshfirstname"];?>

        <?php echo $this->scope["attributes"]["company_osh_representativeoshlastname"];?>

    </div>
    <div class="float-right">
        <?php echo $this->scope["attributes"]["company_osh_phonerepresentative"];?>

        <?php echo $this->scope["attributes"]["company_osh_emailrepresentative"];?>

    </div>
</fieldset>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>