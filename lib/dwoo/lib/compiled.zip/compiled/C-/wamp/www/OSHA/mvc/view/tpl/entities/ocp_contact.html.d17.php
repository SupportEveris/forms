<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><fieldset>
    <legend id="PRIMARY_CONTACT">
        Primary Contact
        <div data-section="PRIMARY_CONTACT" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    
     <!--  <?php if (! 'mf' && (isset($this->scope["partner_type"]) ? $this->scope["partner_type"] : null) == "current") {
?><div><?php echo $this->scope["attributes"]["contact_osh_maincontactchange"];?></div><?php 
}?>-->
 <?php if (! (isset($this->scope["mf"]) ? $this->scope["mf"] : null) && (isset($this->scope["mainContactChangeCheck"]) ? $this->scope["mainContactChangeCheck"] : null) == true && (isset($this->scope["partner_type"]) ? $this->scope["partner_type"] : null) != "current") {
?><div><?php echo $this->scope["attributes"]["contact_osh_maincontactchange"];?></div><?php 
}?> 
    <div class="main-contact-change">
        <div class="float-left">
            <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonfirstname"];?>

            <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonlastname"];?>

            <?php echo $this->scope["attributes"]["contact_osh_positionmaincontactperson"];?>


        </div>
        <div class="float-right" style="margin-top: 2%">
            <?php echo $this->scope["attributes"]["contact_osh_mainphone"];?>

            <?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null) || (isset($this->scope["partner_type"]) ? $this->scope["partner_type"] : null) == "current") {
?>
                <div class="disabledEmailForMF">
            <?php 
}?>

            <?php echo $this->scope["attributes"]["contact_osh_mainemail"];?>

            <?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>
                </div>
            <?php 
}?>

            <?php if (! (isset($this->scope["mf"]) ? $this->scope["mf"] : null) && (isset($this->scope["partner_type"]) ? $this->scope["partner_type"] : null) != "current" && ! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
                <?php echo $this->scope["attributes"]["contact_osh_confirm_mainemail"];?>

            <?php 
}?>

        </div>
    </div>
  <div class="float-left">
            <?php if (! (isset($this->scope["mf"]) ? $this->scope["mf"] : null) && (isset($this->scope["partner_type"]) ? $this->scope["partner_type"] : null) != "current" && ! (isset($this->scope["locked"]) ? $this->scope["locked"] : null) && (isset($this->scope["HelpMessage"]) ? $this->scope["HelpMessage"] : null) != "print") {
?>
            <?php echo $this->scope["attributes"]["contact_osh_captcha"];?>

            <?php 
}?>

        </div>
    <div class="hidden">
        <?php echo $this->scope["attributes"]["helpMessage"];?>

        <?php echo $this->scope["attributes"]["contact_osh_mainemailAux"];?>

        <?php echo $this->scope["attributes"]["company_osh_orgnameAux"];?>

        <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonfirstnameAux"];?>

        <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonlastnameAux"];?>

        <?php echo $this->scope["attributes"]["osh_primarycontactsection"];?>

        <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonfirstname_clone"];?>

        <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonlastname_clone"];?>

        <?php echo $this->scope["attributes"]["contact_osh_positionmaincontactperson_clone"];?>

        <?php echo $this->scope["attributes"]["contact_osh_mainphone_clone"];?>

        <?php echo $this->scope["attributes"]["contact_osh_mainemail_clone"];?>

        <?php if (! (isset($this->scope["mf"]) ? $this->scope["mf"] : null) && (isset($this->scope["partner_type"]) ? $this->scope["partner_type"] : null) != "current" && ! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
            <?php echo $this->scope["attributes"]["contact_osh_confirm_mainemail_clone"];?>

        <?php 
}?>

    </div>
</fieldset>
<?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>
<fieldset id="osh_otheruser">
    <legend id="OTHER_USERS">
        Other users
        <div data-section="OTHER_USERS" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    <p id="general-text">In this section you can add additional contacts for your own organisation. These new users will be able to make changes to your organisational profile. You will always be notified of such changes</p>
   
   <div id="otherUserField1" style="margin-top: -7%;">
        <?php echo $this->scope["attributes"]["contact_osh_otherusername1"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otherusermail1"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otheruserphone1"];?>

        <div class="removeOtherUserDiv" style="margin-top: 2%;">
            <button id="removeOtherUser1" type="button">
                Remove user
            </button>
        </div>
    </div>
   <div id="otherUserField2" style="margin-top: 5%;">
        <?php echo $this->scope["attributes"]["contact_osh_otherusername2"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otherusermail2"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otheruserphone2"];?>

        <div class="removeOtherUserDiv" style="margin-top: 2%;">
            <button id="removeOtherUser2" type="button">
                Remove user
            </button>
        </div>
    </div>
   <div id="otherUserField3" style="margin-top: 5%;">
        <?php echo $this->scope["attributes"]["contact_osh_otherusername3"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otherusermail3"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otheruserphone3"];?>

        <div class="removeOtherUserDiv" style="margin-top: 2%;">
            <button id="removeOtherUser3" type="button">
                Remove user
            </button>
        </div>
    </div>
    <div id="otherUserField4" style="margin-top: 5%;">
        <?php echo $this->scope["attributes"]["contact_osh_otherusername4"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otherusermail4"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otheruserphone4"];?>

        <div class="removeOtherUserDiv" style="margin-top: 2%;">
            <button id="removeOtherUser4" type="button">
                Remove user
            </button>
        </div>
    </div>
    <div id="otherUserField5" style="margin-top: 5%;">
        <?php echo $this->scope["attributes"]["contact_osh_otherusername5"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otherusermail5"];?>

        <?php echo $this->scope["attributes"]["contact_osh_otheruserphone5"];?>

        <div class="removeOtherUserDiv" style="margin-top: 2%;">
            <button id="removeOtherUser5" type="button">
                Remove user
            </button>
        </div>
    </div>
   
   
   <button class="addOtherUser" style="margin-top: 1%;" type="button">
        Add user
    </button>
</fieldset>
<?php 
}?>

<?php if ((isset($this->scope["HelpMessage"]) ? $this->scope["HelpMessage"] : null) == "print") {
?>
<div id="footerPrintFriendly">
    <table style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;" align="center" bgcolor="#2d6a00" border="0" cellpadding="0" cellspacing="0" width="100%">
          <tbody><tr>
             <td class="block_td percent_td" width="50%"><img src="http://hwc-crm.osha.europa.eu/footer.png" alt="" height="88" width="350"></td>    
             <td class="block_td percent_td" align="center" valign="middle" width="50%">
				 <p style="margin:20px 0 !important; color:#ffffff; font-weight:700; font-family: Arial, Helvetica, sans-serif; font-size:16px; line-height: 20px;mso-line-height-rule: exactly;">Follow us on: 
					<a href="https://www.facebook.com/EuropeanAgencyforSafetyandHealthatWork" target="_blank"><img src="http://hwc-crm.osha.europa.eu/facebook.jpg" alt="facebook" align="absmiddle" height="20" border="0" width="20"></a> 
					<a href="https://twitter.com/eu_osha" target="_blank"><img src="http://hwc-crm.osha.europa.eu/twitter.jpg" alt="twitter" align="absmiddle" height="20" border="0" width="20"></a> 
					<a href="https://www.linkedin.com/company/european-agency-for-safety-and-health-at-work" target="_blank"><img src="http://hwc-crm.osha.europa.eu/linkedin.jpg" alt="linkedin" align="absmiddle" height="20" border="0" width="20"></a> 
					<a href="https://www.youtube.com/user/EUOSHA" target="_blank"><img src="http://hwc-crm.osha.europa.eu/youtube.jpg" alt="youtube" align="absmiddle" height="20" border="0" width="20"></a> 
					<a href="https://osha.europa.eu/en/tools-and-publications/blog" target="_blank"><img src="http://hwc-crm.osha.europa.eu/blogger.jpg" alt="blogger" align="absmiddle" height="20" border="0" width="20"></a>
				</p>
			</td>          
          </tr>
         </tbody></table>
</div>
<?php 
}
 /* end template body */
return $this->buffer . ob_get_clean();
?>