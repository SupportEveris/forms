<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="nav-side-menu">
    <div id="sidebar-top" class="menu-list">
        <ul id="menu-content" class="menu-content collapse out">
            <li class="print"><a class="action-print" data-href="<?php echo $this->scope["appurl"];?>&action=printable" href="#"> &gt;Print</a></li>
           <!-- <li class="export-pdf"><a class="action-pdf" data-href="<?php echo $this->scope["appurl"];?>&action=pdf" href="#"> &gt;See example profile</a></li> -->
            <li class="separator">&nbsp;</li>
            <li class="required-fields-box">Required fields</li>
            <li class="fields-campaign">Fields displayed on campaign site<div title="Fields displayed on campaign site" class="screen"></div></li>
            <li class="export-pdf"><a href="mvc/view/pdf/HWC_Public_Profile.pdf" target="_blank">> See how your data will be published in the Campaign website</a></li>
            <li class="separator">&nbsp;</li>
            <?php 
$_fh1_data = (isset($this->scope["sections"]) ? $this->scope["sections"] : null);
if ($this->isTraversable($_fh1_data) == true)
{
	foreach ($_fh1_data as $this->scope['sectionKey']=>$this->scope['section'])
	{
/* -- foreach start output */
?>
                <li class="section-title"><a href="<?php echo $this->scope["appurlsidebar"];?>?route=<?php echo $this->scope["section"]["route"];?>"><?php echo $this->scope["section"]["title"];?></a></li>
                <?php 
$_fh0_data = (isset($this->scope["section"]["sections"]) ? $this->scope["section"]["sections"]:null);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['subsectionKey']=>$this->scope['subsection'])
	{
/* -- foreach start output */
?>
            <?php if ((isset($this->scope["subsectionKey"]) ? $this->scope["subsectionKey"] : null) != "OTHER_USERS") {
?>
            <li class="section <?php echo $this->scope["subsectionKey"];?> <?php if ($this->readVar("sections_validated.".(isset($this->scope["subsectionKey"]) ? $this->scope["subsectionKey"] : null)) == "0") {
?>sidebar-error<?php 
}?>" data-section="<?php echo $this->scope["subsectionKey"];?>">
                <a data-ajax="?route=<?php echo $this->scope["currentRoute"];?>&amp;action=savesessionajax" href="<?php echo $this->scope["appurlsidebar"];?>?route=<?php echo $this->scope["section"]["route"];?>#<?php echo $this->scope["subsectionKey"];?>"><?php echo $this->scope["subsection"];?></a>
            </li>
            <?php 
}
elseif ((isset($this->scope["subsectionKey"]) ? $this->scope["subsectionKey"] : null) == "OTHER_USERS" && (isset($this->scope["mf"]) ? $this->scope["mf"] : null) == "mf") {
?>
            <li class="section OTHER_USERS" data-section="OTHER_USERS">
                <a href="<?php echo $this->scope["appurlsidebar"];?>?route=contact#OTHER_USERS">Other users</a>
            </li>
            <?php 
}?>

                <?php 
/* -- foreach end output */
	}
}?>

            <?php 
/* -- foreach end output */
	}
}?>


            <li class="separator">&nbsp;</li>
            <?php if ((isset($this->scope["locked"]) ? $this->scope["locked"] : null) != "locked" && (isset($this->scope["mf"]) ? $this->scope["mf"] : null) != "mf") {
?>
            <li id="sidebar-bottom" class="menu-list">
                <button id="save" name="save" <?php if ((isset($this->scope["graceperiod"]) ? $this->scope["graceperiod"] : null)) {
?>class="hidden"<?php 
}?>>Save as a draft</button>
            </li>
             <li class="fields-campaign" <?php if ((isset($this->scope["graceperiod"]) ? $this->scope["graceperiod"] : null)) {
?>class="hidden"<?php 
}?>>When saving as a draft, you will receive an automatic email with a link from which you will be able to come back to continue your application. In order to do so, the completion the organisation's name and your primary contact's email is mandatory</li>
            
            <?php 
}?>

        </ul>
    </div>
</div><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>