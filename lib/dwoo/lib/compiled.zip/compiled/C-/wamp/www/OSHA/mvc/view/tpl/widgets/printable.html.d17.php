<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
if ((isset($this->scope["image"]) ? $this->scope["image"] : null)) {
?>
<div><strong><?php if (! empty($this->scope["fieldLabel"])) {

echo $this->scope["fieldLabel"];

}?>:</strong></div>
<?php if (! empty($this->scope["fieldValue"]["content"])) {
?>
<div class="image-printable"><img src="data:image/png;base64,<?php echo $this->scope["fieldValue"]["content"];?>"/></div>
<?php 
}
else {
?>
<div>No image available</div>
<?php 
}?>

<?php 
}
else {
?>
    <?php if (is_array((isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null))) {
?>
    <div><strong><?php if (! empty($this->scope["fieldLabel"])) {

echo $this->scope["fieldLabel"];

}?>:</strong></div>
        <?php 
$_fh0_data = (isset($this->scope["fieldValue"]) ? $this->scope["fieldValue"] : null);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['id']=>$this->scope['value'])
	{
/* -- foreach start output */
?>
            <?php if (! empty($this->scope["selectedValue"]) && ( (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) == (isset($this->scope["value"]) ? $this->scope["value"] : null) || (isset($this->scope["selectedValue"]) ? $this->scope["selectedValue"] : null) == (isset($this->scope["id"]) ? $this->scope["id"] : null) )) {
?>
            <div><strong></strong>&nbsp;<?php echo $this->scope["value"];?></div>
            <?php 
}?>

            <?php if ((isset($this->scope["value"]["selected"]) ? $this->scope["value"]["selected"]:null)) {
?>
            <div><strong></strong>&nbsp;<?php echo $this->scope["value"]["name"];?></div>
            <?php 
}?>

        <?php 
/* -- foreach end output */
	}
}?>

    <?php 
}
else {
?>
    <div><strong><?php if (! empty($this->scope["fieldLabel"])) {

echo $this->scope["fieldLabel"];

}?>:</strong><?php if (! empty($this->scope["fieldValue"])) {
?>&nbsp;<?php echo $this->scope["fieldValue"];

}?></div>
    <?php 
}?>

<?php 
}
 /* end template body */
return $this->buffer . ob_get_clean();
?>