<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!--<fieldset>
    <legend id="PLEDGE">
        Your involvement in the campaign
        <div data-section="PLEDGE" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    
    <?php echo $this->scope["attributes"]["involvement_osh_campaignpledge"];?>

        <div class="hidden">
            <?php echo $this->scope["attributes"]["contact_osh_mainemailAux"];?>

            <?php echo $this->scope["attributes"]["company_osh_orgnameAux"];?>

        </div>
</fieldset> --><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>