<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!--<?php if ((isset($this->scope["HelpMessage"]) ? $this->scope["HelpMessage"] : null) != "print") {
?>
<div id="container-message" class="container-message">   

        <div id="MESSAGE">
            Please make sure you thoroughly check, whether all your information is still valid
                       and indicate <br>     this by checking the button next to the appropiate fields
                       <a class="close">[X]</a>
        </div>            
    </div>
<?php 
}
else {
?>
<?php 
}?>-->
<?php if (! (isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>
<fieldset>
    <legend id="BECOME">
        Why do you want to become a partner?
        <div data-section="BECOME" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    
     <!--<p class='promoteText'>Why do you want to be an Official Campaign Partner of the Healthy Workplaces Campaign 2016-17 on ‘Healthy Workplaces for All Ages’?</p> -->
     <div id="promoteText" class="promoteText marginRightForm">
        <?php echo $this->scope["attributes"]["involvement_osh_tobeanocponhwc"];?>

     </div>
</fieldset>
<fieldset>
    <legend id="INVOLVEMENT">
        Your support for the campaign
        <div data-section="INVOLVEMENT" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    
    <!--<p class='promoteText'>How do you plan to promote and support the campaign via your website and other electronic means  (Intranet, Newsletter, social media etc.)?</p>-->
    <div id="promoteText" class="promoteText marginRightForm" style="width: 100%">
        <?php echo $this->scope["attributes"]["involvement_osh_promoteandsupportcampaign"];?>

    </div>
    
    <div style= "display: inline-block;">
         <p class='promoteText2'>What other activities do you plan to get substantially involved in the campaign?</p>
    </div>
    <p class='promoteText3 promoteText2' style="min-width: 75%;">Please select among the following and describe them briefly.</p>
     
    <?php echo $this->scope["attributes"]["involvement_osh_conferenceactivity"];?>

    <?php echo $this->scope["attributes"]["involvement_osh_trainingsessions"];?>

    <?php echo $this->scope["attributes"]["involvement_osh_partnershipswithotherorganisations"];?>

    <?php echo $this->scope["attributes"]["involvement_osh_promotioninthemedia"];?>

    <?php echo $this->scope["attributes"]["involvement_osh_bestpractice"];?>

    <?php echo $this->scope["attributes"]["involvement_osh_otheractivities"];?>

    
        <div class="hidden">
            <?php echo $this->scope["attributes"]["helpMessage"];?>

            <?php echo $this->scope["attributes"]["contact_osh_mainemailAux"];?>

            <?php echo $this->scope["attributes"]["company_osh_orgnameAux"];?>

            <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonfirstnameAux"];?>

            <?php echo $this->scope["attributes"]["contact_osh_maincontactpersonlastnameAux"];?>

            <?php echo $this->scope["attributes"]["osh_tobecomeapartnersection"];?>

            <?php echo $this->scope["attributes"]["osh_supportforcampaignsection"];?>

            <?php echo $this->scope["attributes"]["osh_yourcampaignpledgesection"];?>

        </div>
</fieldset>
<?php 
}
else {
?>

<?php 
}?>

<fieldset>
    <legend id="PLEDGE">
        Your campaign pledge
        <div data-section="PLEDGE" class="validation<?php echo $this->scope["locked"];?>"></div>
    </legend>
    
    <div class="separatorFieldSet">&nbsp;</div>
    <div class="marginRightForm">
        <?php echo $this->scope["attributes"]["involvement_osh_campaignpledge"];?>

    </div>
</fieldset><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>