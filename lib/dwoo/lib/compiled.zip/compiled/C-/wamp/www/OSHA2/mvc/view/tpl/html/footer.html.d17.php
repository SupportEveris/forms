<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
if (! (isset($this->scope["printable"]) ? $this->scope["printable"] : null)) {
?>
            <?php if (empty($this->scope["hideButtons"])) {
?>
            <div class="control-group">
                <label class="control-label" for="next"></label>
                <div class="controls">
                    <input id="next" name="next" value="<?php echo $this->scope["submit_text"];?>" type="submit" />
                </div>
            </div>
            <?php 
}?>

        <?php if (! (isset($this->scope["locked"]) ? $this->scope["locked"] : null)) {
?>
        </form>
        <?php 
}?>

    <?php if (! ((isset($this->scope["fullwidth"]) ? $this->scope["fullwidth"] : null) !== null)) {
?>
    </div>
    <?php 
}?>

</div>
<div class="clear"></div>
<?php 
}
 /* end template body */
return $this->buffer . ob_get_clean();
?>