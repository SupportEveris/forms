<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="checkbox mainContactCheck">
   <!-- <input <?php echo $this->scope["disabled"];?> type="checkbox" name="<?php echo $this->scope["fieldName"];?>" id="<?php echo $this->scope["fieldName"];?>" data-section="<?php echo $this->scope["fieldSection"];?>" class="main-contact-change-checkbox" /> -->
    <!-- <label><?php echo $this->scope["fieldLabel"];?></label> -->
    <?php if (! empty($this->scope["fieldHelpText"])) {
?>
    <p class="help-block">For typo mistakes in the contacts related fields insert directly the corrections in the bellow fields.</br>
        Should you want to change fully the contact person´s details, please, firstly activate the following box  <input <?php echo $this->scope["disabled"];?> type="checkbox" name="<?php echo $this->scope["fieldName"];?>" id="<?php echo $this->scope["fieldName"];?>" data-section="<?php echo $this->scope["fieldSection"];?>" class="main-contact-change-checkbox" /></br>
    and then provide the new contact´s details in the fields bellow.</p>
    <?php 
}?>

</div>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>