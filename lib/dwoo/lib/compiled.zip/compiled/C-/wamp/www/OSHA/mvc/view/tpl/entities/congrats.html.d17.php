<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><fieldset style="min-width: 75%">

    <?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>
        <?php if ((isset($this->scope["alertFieldsModified"]) ? $this->scope["alertFieldsModified"] : null)) {
?>
            <p class="thank-you">Your changes will be reviewed by the campaign team. You will receive feedback shortly.<br> Thanks for participating in the Healthy Workplaces Campaign!</p>
        <?php 
}
else {
?>
            <p class="thank-you">The fields have been updated successfully, and they will be displayed on the Campaign website tomorrow.<br> Thanks for participating in the Healthy Workplaces Campaign!</p>
        <?php 
}?>

    <?php 
}
else {
?>
        <p class="thank-you">Thank you for submitting your application!</p>
    <?php 
}?>


    <p class="congrats">
        <?php if ((isset($this->scope["category"]) ? $this->scope["category"] : null) == 'ocp' && ! (isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>
        It will be reviewed by the campaign team after 20 May 2016, deadline for applying to become an official campaign partner. You will be informed about the result of your application shortly after.<br>
        You have now 20 minutes to review your application and make corrections if necessary. You just have to follow the link provided in the e-mail confirming the receipt of your application that you will receive shortly.  After that time, the application form will be sent to us for final validation. If you have any problem, please contact us: <a href="mailto:partners@healthy-workplaces.eu">partners@healthy-workplaces.eu</a>
        <?php 
}?>

        <?php if ((isset($this->scope["category"]) ? $this->scope["category"] : null) == 'mp' && ! (isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>
        You have now 20 minutes to review your application and make corrections if necessary. You just have to follow the link provided in the e-mail confirming the receipt of your application that you will receive shortly.  After that time, the application form will be sent to us for final validation. If you have any problem, please contact us: <a href="mailto:partners@healthy-workplaces.eu">partners@healthy-workplaces.eu</a>.<br>
        Once the application is validated, your profile will be published on <a href="https://www.healthy-workplaces.eu/en/campaign-partners/media-partners">https://www.healthy-workplaces.eu/en/campaign-partners/media-partners</a>.
        <?php 
}?>

    </p>
    <div class="control-group">
        <div class="print-finish">
            <div><a href="<?php echo $this->scope["homeurl"];?>?action=printable" target="_blank"><img src="<?php echo $this->scope["homeurl"];?>/mvc/view/img/print.png" /></a></div>
            <div><a class="congrats2" href="<?php echo $this->scope["homeurl"];?>?action=printable" target="_blank">&gt;You can print your application form by clicking here</a></div>
        </div>
        
        <?php if ((isset($this->scope["mf"]) ? $this->scope["mf"] : null)) {
?>
            <div class="controls center">
                <a class="button privateZoneredirectMF">Go to homepage</a>
                <input id="partner_nid" class="hidden" name="partner_nid" type="text" value="<?php echo $this->scope["partner_nid"];?>">
                <input id="language" class="hidden" name="language" type="text" value="<?php echo $this->scope["language"];?>">
                <input id="appurl" class="hidden" name="appurl" type="text" value="<?php echo $this->scope["httpHost"];?>">
            </div>
        <?php 
}
else {
?>
            <div class="controls center">
                <a class="button privateZoneredirect">Go to homepage</a>
           <!-- <input id="next" name="next" value="Back to homepage" type="submit" data-error="">-->
            </div>
        <?php 
}?>

    </div>
</fieldset><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>